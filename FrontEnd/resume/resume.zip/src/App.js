import React from "react";
import Personal from "./components/personal/Personal";
import routing from "./Routing";

function App() {
  // return <div>{routing}</div>;
  return (
    <div>
      <Personal />
      {routing}
    </div>
  );
}

export default App;
