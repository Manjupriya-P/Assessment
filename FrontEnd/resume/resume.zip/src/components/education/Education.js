import React from "react";
import "./Education.css";

function Education() {
  return (
    <div className="body">
      <form className="form">
        <div>
          <h1>Education Details</h1>
          <div>
            <input
              type="text"
              className="input"
              placeholder="College/University"
            />
            <input
              type="date"
              id="date"
              placeholder="dd-mm-yyyy"
              title="Start Date"
            />
            <input
              type="date"
              id="date"
              placeholder="dd-mm-yyyy"
              title="End Date"
            />
          </div>
          <div>
            <input type="text" className="qual" placeholder="Qualification" />
            <input type="text" className="des" placeholder="Description" />
          </div>
          <div>
            <input
              type="text"
              className="input"
              placeholder="College/University"
            />
            <input
              type="date"
              id="date"
              placeholder="dd-mm-yyyy"
              title="Start Date"
            />
            <input
              type="date"
              id="date"
              placeholder="dd-mm-yyyy"
              title="End Date"
            />
          </div>
          <div>
            <input type="text" className="qual" placeholder="Qualification" />
            <input type="text" className="des" placeholder="Description" />
          </div>
          <br></br>
          <div>
            <a href="./../experience/Experience.js">
              <input
                type="button"
                className="button1"
                value=" &lt; back"
              ></input>
            </a>

            <input type="button" className="button1" value=" next &gt;" />
          </div>
        </div>
      </form>
    </div>
  );
}

export default Education;
