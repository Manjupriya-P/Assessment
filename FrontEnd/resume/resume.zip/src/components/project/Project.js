import React from "react";
import "./Project.css";

function Project() {
  return (
    <div className="body">
      <form className="form">
        <div>
          <div>
            {/* &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; */}
            <h1> Projects Developed</h1>
            <h3>Project 1</h3>
            <input type="text" placeholder="title"></input>
            <input type="text" placeholder="link"></input>
            <input type="text" placeholder="Description"></input>
          </div>
          <div>
            <h3>Project 2</h3>
            <input type="text" placeholder="title"></input>
            <input type="text" placeholder="link"></input>
            <input type="text" placeholder="Description"></input>
          </div>
          <br></br>
          <div>
            <input type="button" className="button1" value=" &lt; back"></input>
            <input type="button" className="button1" value=" next &gt;" />
          </div>
        </div>
      </form>
    </div>
  );
}

export default Project;
